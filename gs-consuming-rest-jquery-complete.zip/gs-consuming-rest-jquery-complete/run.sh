spring run app.groovy
